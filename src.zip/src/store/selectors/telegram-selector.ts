import {AppRootStateType} from "../store";

export const TelegramSelector = () => {}